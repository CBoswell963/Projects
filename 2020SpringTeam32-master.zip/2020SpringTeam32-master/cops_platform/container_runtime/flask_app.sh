# 'source flask_app.sh to run
# Author: Spencer Yoder
export FLASK_APP=container_runtime.py
export ENFORCED=true
