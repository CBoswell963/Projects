#You can load this alias by just running 'source compile_alias.sh'
alias secompile="make -f /usr/share/selinux/devel/Makefile course_manager.pp"
alias sebuild="sudo semodule -i course_manager.pp"
