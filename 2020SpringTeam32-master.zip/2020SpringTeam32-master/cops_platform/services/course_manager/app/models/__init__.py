from ..models.student import Student
from ..models.course import Course
from ..models.course_student_mapping import CourseStudentMapping
from ..models.coordinator import Coordinator
from ..models.instructor import Instructor

